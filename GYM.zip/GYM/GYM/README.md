CrossFit gym management system developed with help of jsp ,css,html ,java and in backend used the mysql for database developed in netbeans

there are basically two modules 
1.Admin
2.User(Member)

##Admin can login and create a account for himself in admin can add/update/delete/view trainer,member and receptionist and can view the enquiry 

##Member can  add and view himself

