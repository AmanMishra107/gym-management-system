/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;
import Database.DatabaseConnection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/contact")


/**
 *
 * @author Admin
 */
public class contact extends HttpServlet {
    private int i;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter pw = response.getWriter();
        try {
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String query = request.getParameter("query");

            Connection con = DatabaseConnection.initializeDatabase();
            PreparedStatement pst = con.prepareStatement("INSERT INTO contact (name, email, query) VALUES (?, ?, ?)");

            pst.setString(1, name);
            pst.setString(2, email);
            pst.setString(3, query);

            i = pst.executeUpdate();
            if (i > 0) {
                pw.println("<script type=\"text/javascript\">");
                pw.println("alert('Data Inserted Successfully..!');");
                pw.println("window.location.href = \"index.html\";");
                pw.println("</script>");
            } else {
                pw.println("<script type=\"text/javascript\">");
                pw.println("alert('Failed to Insert Data..!');");
                pw.println("window.location.href = \"contact.jsp\";");
                pw.println("</script>");
            }

            // Close resources
            pst.close();
            con.close();

        } catch (SQLException ex) {
            Logger.getLogger(contact.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(contact.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}