package Controller;

import Database.DatabaseConnection;
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/UpdateTrainerServlet")
public class UpdateTrainerServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // Prepare the update statement
        int id = Integer.parseInt(request.getParameter("id"));
        String fname = request.getParameter("fname");
        String lname = request.getParameter("lname");
        String gender = request.getParameter("gender");
        String mobile = request.getParameter("mobile");
        String city = request.getParameter("city");
        String email = request.getParameter("email");
        String age = request.getParameter("age");
        String address = request.getParameter("address");
        String date = request.getParameter("date");
        String experience = request.getParameter("experience");

        try {
            Connection con = DatabaseConnection.initializeDatabase();
            PreparedStatement ps = con.prepareStatement("UPDATE trainer SET fname=?, lname=?, gender=?, mobile=?, city=?, email=?, age=?, address=?, date=?, experience=? WHERE id=?");
            ps.setString(1, fname);
            ps.setString(2, lname);
            ps.setString(3, gender);
            ps.setString(4, mobile);
            ps.setString(5, city);
            ps.setString(6, email);
            ps.setString(7, age);
            ps.setString(8, address);
            ps.setString(9, date);
            ps.setString(10, experience);
            ps.setInt(11, id);

          int rowsAffected = ps.executeUpdate();
        
        // Close resources
        ps.close();
        con.close();
        
        // Redirect to a confirmation page
        response.sendRedirect("adminTrainerList.jsp?rowsAffected=" + rowsAffected);
    } catch (Exception e) {
        out.println(e);
    }

        }

    }

